<?php
require_once '../includes/auth.php';
require_once '../config/db.php';

$id_utilisateur = $_SESSION['user']['id_utilisateur'];

// Simulation : récupérer les articles du panier
$panier = $pdo->prepare("SELECT * FROM panier WHERE id_utilisateur = ?");
$panier->execute([$id_utilisateur]);
$articles = $panier->fetchAll();

// Simulation ID de transaction
$trx_id = 'TRX' . time();

foreach ($articles as $item) {
    $stmt = $pdo->prepare("INSERT INTO commandes (id_utilisateur, id_produit, quantite, id_transaction, statut_paiement)
        VALUES (?, ?, ?, ?, 'Payé')");
    $stmt->execute([
        $id_utilisateur,
        $item['id_produit'],
        $item['quantite'],
        $trx_id
    ]);
}

// Vider le panier
$pdo->prepare("DELETE FROM panier WHERE id_utilisateur = ?")->execute([$id_utilisateur]);

include '../includes/header.php';
?>

<h2>Paiement réussi</h2>
<p>Votre commande a été enregistrée avec la transaction <strong><?= $trx_id ?></strong>.</p>

<?php include '../includes/footer.php'; ?>
