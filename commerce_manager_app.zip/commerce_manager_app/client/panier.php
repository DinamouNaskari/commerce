<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'client') {
    header('Location: ../pages/login.php');
    exit;
}

$id_user = $_SESSION['user'];

// Ajouter au panier
if (isset($_GET['add'])) {
    $id_produit = intval($_GET['add']);
    $stmt = $pdo->prepare("INSERT INTO panier (id_produit, id_utilisateur, adresse_ip, quantite)
                           VALUES (?, ?, ?, 1)
                           ON DUPLICATE KEY UPDATE quantite = quantite + 1");
    $stmt->execute([$id_produit, $id_user, $_SERVER['REMOTE_ADDR']]);
    header("Location: panier.php");
    exit;
}

// Supprimer du panier
if (isset($_GET['remove'])) {
    $id = intval($_GET['remove']);
    $pdo->prepare("DELETE FROM panier WHERE id = ? AND id_utilisateur = ?")->execute([$id, $id_user]);
    header("Location: panier.php");
    exit;
}

// Afficher panier
$stmt = $pdo->prepare("SELECT p.*, pa.id AS id_panier, pa.quantite FROM panier pa 
                       JOIN produits p ON pa.id_produit = p.id_produit 
                       WHERE pa.id_utilisateur = ?");
$stmt->execute([$id_user]);
$panier = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Panier</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Mon Panier</h2>
    <a href="produits.php" class="btn btn-secondary mb-3">Retour aux produits</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Produit</th>
                <th>Prix</th>
                <th>Quantité</th>
                <th>Total</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $total = 0; foreach ($panier as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['nom_produit']) ?></td>
                    <td><?= $item['prix_vente'] ?></td>
                    <td><?= $item['quantite'] ?></td>
                    <td><?= $item['quantite'] * $item['prix_vente'] ?></td>
                    <td>
                        <a href="panier.php?remove=<?= $item['id_panier'] ?>" class="btn btn-danger btn-sm">Supprimer</a>
                    </td>
                </tr>
                <?php $total += $item['quantite'] * $item['prix_vente']; ?>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h4>Total : <?= $total ?> FCFA</h4>
    <a href="commander.php" class="btn btn-success">Passer la commande</a>
</div>
</body>
</html>
