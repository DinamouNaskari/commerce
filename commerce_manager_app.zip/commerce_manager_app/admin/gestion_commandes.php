<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../pages/login.php');
    exit;
}

// Mettre à jour le statut
if (isset($_GET['id']) && isset($_GET['statut'])) {
    $id = intval($_GET['id']);
    $statut = $_GET['statut'];

    $update = $pdo->prepare("UPDATE commandes SET statut_paiement = ? WHERE id_commande = ?");
    $update->execute([$statut, $id]);

    header("Location: gestion_commandes.php");
    exit;
}

// Liste des commandes
$stmt = $pdo->query("
    SELECT c.*, u.prenom, u.nom, p.nom_produit
    FROM commandes c
    JOIN utilisateurs u ON c.id_utilisateur = u.id_utilisateur
    JOIN produits p ON c.id_produit = p.id_produit
    ORDER BY c.cree_le DESC
");
$commandes = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des commandes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Gestion des commandes</h2>
    <a href="index.php" class="btn btn-secondary mb-3">Retour au tableau de bord</a>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Client</th>
                <th>Produit</th>
                <th>Quantité</th>
                <th>Statut</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($commandes as $cmd): ?>
            <tr>
                <td><?= $cmd['id_commande'] ?></td>
                <td><?= htmlspecialchars($cmd['prenom'] . ' ' . $cmd['nom']) ?></td>
                <td><?= htmlspecialchars($cmd['nom_produit']) ?></td>
                <td><?= $cmd['quantite'] ?></td>
                <td>
                    <span class="badge bg-info"><?= $cmd['statut_paiement'] ?></span>
                </td>
                <td><?= $cmd['cree_le'] ?></td>
                <td>
                    <form method="get" class="d-flex gap-1">
                        <input type="hidden" name="id" value="<?= $cmd['id_commande'] ?>">
                        <select name="statut" class="form-select form-select-sm">
                            <option <?= $cmd['statut_paiement'] === 'En attente' ? 'selected' : '' ?>>En attente</option>
                            <option <?= $cmd['statut_paiement'] === 'Payé' ? 'selected' : '' ?>>Payé</option>
                            <option <?= $cmd['statut_paiement'] === 'Expédié' ? 'selected' : '' ?>>Expédié</option>
                            <option <?= $cmd['statut_paiement'] === 'Livré' ? 'selected' : '' ?>>Livré</option>
                            <option <?= $cmd['statut_paiement'] === 'Annulé' ? 'selected' : '' ?>>Annulé</option>
                        </select>
                        <button class="btn btn-sm btn-primary">Mettre à jour</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
