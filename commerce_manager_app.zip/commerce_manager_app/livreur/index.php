<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'livreur') {
    header('Location: ../pages/login.php');
    exit;
}

$id_livreur = $_SESSION['user'];

// Livraisons assignées
$stmt = $pdo->prepare("SELECT COUNT(*) FROM livraison WHERE id_livreur = ?");
$stmt->execute([$id_livreur]);
$total = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Dashboard Livreur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Bienvenue Livreur</h2>
    <p><strong>Livraisons assignées : </strong><?= $total ?></p>
    <a href="livraisons.php" class="btn btn-primary">Voir les livraisons</a>
    <a href="../pages/logout.php" class="btn btn-danger">Déconnexion</a>
</div>
</body>
</html>
