<?php
session_start();
require_once '../includes/db.php';

// Vérification de sécurité
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../pages/login.php');
    exit;
}

// Supprimer un utilisateur
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM utilisateurs WHERE id_utilisateur = ?");
    $stmt->execute([$id]);
    header('Location: gestion_utilisateurs.php');
    exit;
}

// Activer/Désactiver un utilisateur
if (isset($_GET['toggle'])) {
    $id = intval($_GET['toggle']);
    $stmt = $pdo->prepare("SELECT actif FROM utilisateurs WHERE id_utilisateur = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();

    if ($user) {
        $nouvelEtat = $user['actif'] === '1' ? '0' : '1';
        $update = $pdo->prepare("UPDATE utilisateurs SET actif = ? WHERE id_utilisateur = ?");
        $update->execute([$nouvelEtat, $id]);
    }

    header('Location: gestion_utilisateurs.php');
    exit;
}

// Récupérer tous les utilisateurs
$stmt = $pdo->query("SELECT * FROM utilisateurs ORDER BY cree_le DESC");
$utilisateurs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des utilisateurs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Gestion des utilisateurs</h2>
        <a href="index.php" class="btn btn-secondary mb-3">Retour au tableau de bord</a>

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Téléphone</th>
                    <th>Profession</th>
                    <th>État</th>
                    <th>Créé le</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($utilisateurs as $u): ?>
                    <tr>
                        <td><?= $u['id_utilisateur'] ?></td>
                        <td><?= htmlspecialchars($u['prenom'] . ' ' . $u['nom']) ?></td>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td><?= htmlspecialchars($u['telephone']) ?></td>
                        <td><?= ucfirst($u['profession']) ?></td>
                        <td>
                            <?php if ($u['actif'] === '1'): ?>
                                <span class="badge bg-success">Actif</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Inactif</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $u['cree_le'] ?></td>
                        <td>
                            <a href="?toggle=<?= $u['id_utilisateur'] ?>" class="btn btn-sm <?= $u['actif'] === '1' ? 'btn-warning' : 'btn-success' ?>">
                                <?= $u['actif'] === '1' ? 'Désactiver' : 'Activer' ?>
                            </a>
                            <a href="?delete=<?= $u['id_utilisateur'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer la suppression ?')">
                                Supprimer
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
