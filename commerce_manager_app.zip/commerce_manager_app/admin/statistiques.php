<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../pages/login.php');
    exit;
}

$nbProduits = $pdo->query("SELECT COUNT(*) FROM produits")->fetchColumn();
$nbCommandes = $pdo->query("SELECT COUNT(*) FROM commandes")->fetchColumn();
$nbClients = $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE profession = 'client'")->fetchColumn();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Statistiques</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Statistiques générales</h2>
    <canvas id="chartStats" height="100"></canvas>
</div>

<script>
const ctx = document.getElementById('chartStats');
const chart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Produits', 'Commandes', 'Clients'],
        datasets: [{
            label: 'Totaux',
            data: [<?= $nbProduits ?>, <?= $nbCommandes ?>, <?= $nbClients ?>],
            backgroundColor: ['blue', 'green', 'orange']
        }]
    }
});
</script>
</body>
</html>
