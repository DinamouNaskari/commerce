<?php
session_start();
require_once '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Vérifie dans les administrateurs
    $stmt = $pdo->prepare("SELECT * FROM administrateurs WHERE email = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['mot_de_passe'])) {
        $_SESSION['user'] = $admin;
        $_SESSION['role'] = 'admin';
        header("Location: ../admin/dashboard.php");
        exit;
    }

    // Vérifie dans les utilisateurs
    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['mot_de_passe'])) {
        $_SESSION['user'] = $user;
        $_SESSION['role'] = 'utilisateur';
        header("Location: ../utilisateurs/accueil.php");
        exit;
    }

    $erreur = "Identifiants incorrects.";
}
?>

<?php include '../includes/header.php'; ?>
<h2>Connexion</h2>
<form method="post">
    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" required class="form-control">
    </div>
    <div class="mb-3">
        <label>Mot de passe</label>
        <input type="password" name="password" required class="form-control">
    </div>
    <button class="btn btn-primary" type="submit">Connexion</button>
    <p class="mt-3">Pas encore de compte ? <a href="register.php">Créer un compte</a></p>
</form>
<?php include '../includes/footer.php'; ?>
