<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../pages/login.php');
    exit;
}

// Récupérer quelques statistiques simples
$nbUtilisateurs = $pdo->query("SELECT COUNT(*) FROM utilisateurs")->fetchColumn();
$nbProduits = $pdo->query("SELECT COUNT(*) FROM produits")->fetchColumn();
$nbCommandes = $pdo->query("SELECT COUNT(*) FROM commandes")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Bienvenue, Administrateur</h1>
        <p><a href="../pages/logout.php" class="btn btn-danger">Déconnexion</a></p>

        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card text-bg-primary mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Utilisateurs inscrits</h5>
                        <p class="card-text fs-4"><?= $nbUtilisateurs ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-bg-success mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Produits</h5>
                        <p class="card-text fs-4"><?= $nbProduits ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-bg-warning mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Commandes</h5>
                        <p class="card-text fs-4"><?= $nbCommandes ?></p>
                    </div>
                </div>
            </div>
        </div>

        <a href="gestion_utilisateurs.php" class="btn btn-outline-secondary">Gérer les utilisateurs</a>
        <a href="gestion_commandes.php" class="btn btn-outline-secondary">Gérer les commandes</a>
    </div>
</body>
</html>
