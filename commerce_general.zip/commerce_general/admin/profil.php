<?php
require_once '../includes/auth.php';
require_once '../config/db.php';

$user = $_SESSION['user'];
$id = $user['id_utilisateur'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $telephone = $_POST['telephone'];

    // upload image
    if ($_FILES['photo']['name']) {
        $file_name = time() . '_' . basename($_FILES['photo']['name']);
        $target = "../uploads/" . $file_name;
        move_uploaded_file($_FILES['photo']['tmp_name'], $target);

        $stmt = $pdo->prepare("UPDATE utilisateurs SET nom=?, prenom=?, telephone=?, photo=? WHERE id_utilisateur=?");
        $stmt->execute([$nom, $prenom, $telephone, $file_name, $id]);

        $_SESSION['user']['photo'] = $file_name;
    } else {
        $stmt = $pdo->prepare("UPDATE utilisateurs SET nom=?, prenom=?, telephone=? WHERE id_utilisateur=?");
        $stmt->execute([$nom, $prenom, $telephone, $id]);
    }

    // mettre à jour la session
    $_SESSION['user']['nom'] = $nom;
    $_SESSION['user']['prenom'] = $prenom;
    $_SESSION['user']['telephone'] = $telephone;

    $success = "Profil mis à jour";
}

include '../includes/header.php';
?>

<h2>Mon profil</h2>
<?php if (isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
<form method="post" enctype="multipart/form-data">
    <div class="mb-3">
        <label>Prénom</label>
        <input name="prenom" value="<?= htmlspecialchars($user['prenom']) ?>" class="form-control">
    </div>
    <div class="mb-3">
        <label>Nom</label>
        <input name="nom" value="<?= htmlspecialchars($user['nom']) ?>" class="form-control">
    </div>
    <div class="mb-3">
        <label>Téléphone</label>
        <input name="telephone" value="<?= htmlspecialchars($user['telephone']) ?>" class="form-control">
    </div>
    <div class="mb-3">
        <label>Photo de profil</label><br>
        <?php if ($user['photo']): ?>
            <img src="../uploads/<?= $user['photo'] ?>" width="100"><br>
        <?php endif; ?>
        <input type="file" name="photo" class="form-control">
    </div>
    <button class="btn btn-primary" type="submit">Modifier</button>
</form>

<?php include '../includes/footer.php'; ?>
