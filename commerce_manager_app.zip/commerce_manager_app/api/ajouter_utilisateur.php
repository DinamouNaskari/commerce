<?php
require_once '../includes/db.php';

$data = json_decode(file_get_contents("php://input"), true);
if (!$data) die("Aucune donnée");

$mdp = password_hash($data['mot_de_passe'], PASSWORD_BCRYPT);

$stmt = $pdo->prepare("INSERT INTO utilisateurs (prenom, nom, email, mot_de_passe, telephone, adresse, profession)
                       VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([
    $data['prenom'], $data['nom'], $data['email'], $mdp,
    $data['telephone'], $data['adresse'], $data['profession']
]);

echo json_encode(['status' => 'utilisateur ajouté']);
