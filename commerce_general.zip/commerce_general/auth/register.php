<?php
require_once '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $stmt = $pdo->prepare("INSERT INTO utilisateurs (prenom, nom, email, mot_de_passe, telephone, adresse1, adresse2)
        VALUES (?, ?, ?, ?, ?, ?, ?)");

    $stmt->execute([
        $_POST['prenom'],
        $_POST['nom'],
        $_POST['email'],
        password_hash($_POST['password'], PASSWORD_BCRYPT),
        $_POST['telephone'],
        $_POST['adresse1'],
        $_POST['adresse2']
    ]);

    header("Location: login.php");
    exit;
}
?>

<?php include '../includes/header.php'; ?>
<h2>Créer un compte</h2>
<form method="post">
    <input name="prenom" required placeholder="Prénom" class="form-control mb-2">
    <input name="nom" required placeholder="Nom" class="form-control mb-2">
    <input name="email" type="email" required placeholder="Email" class="form-control mb-2">
    <input name="password" type="password" required placeholder="Mot de passe" class="form-control mb-2">
    <input name="telephone" required placeholder="Téléphone" class="form-control mb-2">
    <input name="adresse1" placeholder="Adresse 1" class="form-control mb-2">
    <input name="adresse2" placeholder="Adresse 2" class="form-control mb-2">
    <button type="submit" class="btn btn-success">S'inscrire</button>
</form>
<?php include '../includes/footer.php'; ?>
