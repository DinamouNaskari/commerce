<?php
require_once '../includes/auth.php';
if ($_SESSION['role'] !== 'admin') die("Accès refusé");
include '../includes/header.php';
?>
<h1>Tableau de bord Administrateur</h1>
<p>Bienvenue, <?= htmlspecialchars($_SESSION['user']['nom']) ?>.</p>
<?php include '../includes/footer.php'; ?>
