<?php
session_start();
require_once '../includes/db.php';

// Vérifier que le rôle est vendeur
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'vendeur') {
    header('Location: ../pages/login.php');
    exit;
}

$id_vendeur = $_SESSION['user'];

// Nombre de produits
$stmt = $pdo->prepare("SELECT COUNT(*) FROM produits WHERE id_produit IN 
    (SELECT id_produit FROM fournisseur WHERE id = ?)");
$stmt->execute([$id_vendeur]);
$nbProduits = $stmt->fetchColumn();

// Nombre de commandes reçues
$stmt2 = $pdo->prepare("SELECT COUNT(*) FROM commandes WHERE id_produit IN 
    (SELECT id_produit FROM fournisseur WHERE id = ?)");
$stmt2->execute([$id_vendeur]);
$nbCommandes = $stmt2->fetchColumn();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Vendeur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Bienvenue Vendeur</h2>
    <a href="../pages/logout.php" class="btn btn-danger mb-3">Déconnexion</a>

    <div class="row">
        <div class="col-md-6">
            <div class="card bg-info text-white mb-3">
                <div class="card-body">
                    <h5 class="card-title">Mes produits</h5>
                    <p class="card-text fs-4"><?= $nbProduits ?></p>
                    <a href="produits.php" class="btn btn-light btn-sm">Gérer les produits</a>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card bg-warning text-dark mb-3">
                <div class="card-body">
                    <h5 class="card-title">Commandes reçues</h5>
                    <p class="card-text fs-4"><?= $nbCommandes ?></p>
                    <a href="commandes.php" class="btn btn-dark btn-sm">Voir commandes</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
