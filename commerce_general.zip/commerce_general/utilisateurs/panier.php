<?php
require_once '../includes/auth.php';
require_once '../config/db.php';
include '../includes/header.php';

$id_utilisateur = $_SESSION['user']['id_utilisateur'];

$panier = $pdo->prepare("SELECT panier.*, produits.nom_produit, produits.prix 
                         FROM panier
                         JOIN produits ON panier.id_produit = produits.id_produit
                         WHERE id_utilisateur = ?");
$panier->execute([$id_utilisateur]);
$articles = $panier->fetchAll();
?>

<h2>Votre panier</h2>
<table class="table">
    <tr><th>Produit</th><th>Quantité</th><th>Prix</th><th>Total</th></tr>
    <?php 
    $total = 0;
    foreach ($articles as $item): 
        $sous_total = $item['quantite'] * $item['prix'];
        $total += $sous_total;
    ?>
    <tr>
        <td><?= $item['nom_produit'] ?></td>
        <td><?= $item['quantite'] ?></td>
        <td><?= $item['prix'] ?> FCFA</td>
        <td><?= $sous_total ?> FCFA</td>
    </tr>
    <?php endforeach; ?>
    <tr><td colspan="3"><strong>Total</strong></td><td><strong><?= $total ?> FCFA</strong></td></tr>
</table>

<a href="payer.php" class="btn btn-success">Payer</a>

<?php include '../includes/footer.php'; ?>
