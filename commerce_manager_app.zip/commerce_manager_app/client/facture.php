<?php
require '../vendor/autoload.php';
require '../includes/db.php';

use FPDF;

session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'client') {
    header('Location: ../pages/login.php');
    exit;
}

$id_user = $_SESSION['user'];

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,'Facture Client');

$stmt = $pdo->prepare("SELECT c.*, p.nom_produit FROM commandes c 
                       JOIN produits p ON p.id_produit = c.id_produit 
                       WHERE c.id_utilisateur = ?");
$stmt->execute([$id_user]);
$commandes = $stmt->fetchAll();

$pdf->SetFont('Arial','',12);
$pdf->Ln(10);
foreach ($commandes as $c) {
    $pdf->Cell(0, 10, $c['nom_produit'] . " - " . $c['quantite'] . " pcs - " . $c['statut_paiement'], 0, 1);
}

$pdf->Output();
