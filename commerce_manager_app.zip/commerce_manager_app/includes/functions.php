<?php
function log_action($pdo, $id_user, $action) {
    $stmt = $pdo->prepare("INSERT INTO historique (id_utilisateur, action) VALUES (?, ?)");
    $stmt->execute([$id_user, $action]);
}
