CREATE DATABASE IF NOT EXISTS commerce_manager CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE commerce_manager;

-- Table : administrateurs
CREATE TABLE administrateurs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  mot_de_passe VARCHAR(255) NOT NULL,
  actif ENUM('0','1') NOT NULL DEFAULT '0',
  cree_le TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CHECK (CHAR_LENGTH(mot_de_passe) >= 60) -- pour imposer que le mot de passe est haché (ex: bcrypt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table : marques
CREATE TABLE marques (
  id_marque INT AUTO_INCREMENT PRIMARY KEY,
  nom_marque VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table : categories
CREATE TABLE categories (
  id_categorie INT AUTO_INCREMENT PRIMARY KEY,
  nom_categorie VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table : produits
CREATE TABLE produits (
  id_produit INT AUTO_INCREMENT PRIMARY KEY,
  id_categorie INT NOT NULL,
  id_marque INT NOT NULL,
  nom_produit VARCHAR(255) NOT NULL,
  prix DECIMAL(10,2) NOT NULL CHECK (prix >= 0),
  quantite INT NOT NULL DEFAULT 0 CHECK (quantite >= 0),
  description TEXT,
  image TEXT,
  mots_cles TEXT,
  FOREIGN KEY (id_categorie) REFERENCES categories(id_categorie) ON DELETE CASCADE,
  FOREIGN KEY (id_marque) REFERENCES marques(id_marque) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table : utilisateurs
CREATE TABLE utilisateurs (
  id_utilisateur INT AUTO_INCREMENT PRIMARY KEY,
  prenom VARCHAR(100) NOT NULL,
  nom VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  mot_de_passe VARCHAR(255) NOT NULL,
  telephone VARCHAR(15) NOT NULL,
  adresse1 VARCHAR(255),
  adresse2 VARCHAR(255),
  cree_le TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CHECK (CHAR_LENGTH(mot_de_passe) >= 60) -- présume hashage (ex: bcrypt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table : panier
CREATE TABLE panier (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_produit INT NOT NULL,
  adresse_ip VARCHAR(45) NOT NULL,
  id_utilisateur INT,
  quantite INT NOT NULL DEFAULT 1 CHECK (quantite > 0),
  ajoute_le TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_produit) REFERENCES produits(id_produit) ON DELETE CASCADE,
  FOREIGN KEY (id_utilisateur) REFERENCES utilisateurs(id_utilisateur) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table : commandes
CREATE TABLE commandes (
  id_commande INT AUTO_INCREMENT PRIMARY KEY,
  id_utilisateur INT NOT NULL,
  id_produit INT NOT NULL,
  quantite INT NOT NULL CHECK (quantite > 0),
  id_transaction VARCHAR(255) NOT NULL,
  statut_paiement ENUM('En attente','Payé','Expédié','Livré','Annulé') NOT NULL DEFAULT 'En attente',
  cree_le TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_utilisateur) REFERENCES utilisateurs(id_utilisateur) ON DELETE CASCADE,
  FOREIGN KEY (id_produit) REFERENCES produits(id_produit) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

