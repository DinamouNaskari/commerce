<?php
session_start();
require_once '../includes/db.php';
require '../vendor/get_oauth_token.php'; // PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'client') {
    header('Location: ../pages/login.php');
    exit;
}

$id_user = $_SESSION['user'];
$transaction_id = uniqid('trx_');

// Récupérer le panier
$stmt = $pdo->prepare("SELECT * FROM panier WHERE id_utilisateur = ?");
$stmt->execute([$id_user]);
$panier = $stmt->fetchAll();

foreach ($panier as $item) {
    $insert = $pdo->prepare("INSERT INTO commandes (id_utilisateur, id_produit, quantite, id_transaction, statut_paiement)
                             VALUES (?, ?, ?, ?, 'En attente')");
    $insert->execute([$id_user, $item['id_produit'], $item['quantite'], $transaction_id]);
}

// Vider le panier
$pdo->prepare("DELETE FROM panier WHERE id_utilisateur = ?")->execute([$id_user]);

// 📧 Récupérer l'email du client
$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id_utilisateur = ?");
$stmt->execute([$id_user]);
$user = $stmt->fetch();

// ✉️ Envoi de l’email
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Ex: smtp.mailtrap.io pour test local
    $mail->SMTPAuth = true;
    $mail->Username = 'tonemail@gmail.com'; // ✅ ton email
    $mail->Password = 'motdepasse-app';     // ✅ mot de passe d’application
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('tonemail@gmail.com', 'CommerceManager');
    $mail->addAddress($user['email'], $user['prenom'] . ' ' . $user['nom']);

    $mail->isHTML(true);
    $mail->Subject = 'Confirmation de commande';
    $mail->Body    = "Bonjour <b>{$user['prenom']}</b>,<br><br>
                      Votre commande <b>{$transaction_id}</b> a bien été enregistrée.<br>
                      Merci pour votre achat sur CommerceManager !";

    $mail->send();
} catch (Exception $e) {
    // ⚠️ Tu peux log l'erreur dans une table ou fichier si nécessaire
}

// ✅ Redirection après tout
header("Location: paiement.php?trx=" . $transaction_id);
exit;
