<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$id_user = $_SESSION['user'];
$role = $_SESSION['role'];

if ($role === 'admin') {
    header('Location: dashboard.php');
    exit;
}

// Récupérer les infos
$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id_utilisateur = ?");
$stmt->execute([$id_user]);
$user = $stmt->fetch();

// Mettre à jour
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];
    $telephone = $_POST['telephone'];
    $adresse = $_POST['adresse'];

    $update = $pdo->prepare("UPDATE utilisateurs SET prenom = ?, nom = ?, telephone = ?, adresse = ? WHERE id_utilisateur = ?");
    $update->execute([$prenom, $nom, $telephone, $adresse, $id_user]);

    log_action($pdo, $id_user, "Modification du profil");
    header('Location: profile.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mon Profil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Modifier mon profil</h2>
    <form method="POST">
        <div class="mb-3">
            <label>Prénom</label>
            <input type="text" name="prenom" class="form-control" value="<?= htmlspecialchars($user['prenom']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Nom</label>
            <input type="text" name="nom" class="form-control" value="<?= htmlspecialchars($user['nom']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Téléphone</label>
            <input type="text" name="telephone" class="form-control" value="<?= htmlspecialchars($user['telephone']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Adresse</label>
            <input type="text" name="adresse" class="form-control" value="<?= htmlspecialchars($user['adresse']) ?>">
        </div>
        <button class="btn btn-primary">Mettre à jour</button>
    </form>
</div>
</body>
</html>
