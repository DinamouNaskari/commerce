<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'client') {
    header('Location: ../pages/login.php');
    exit;
}

$produits = $pdo->query("SELECT * FROM produits")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Produits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Catalogue de Produits</h2>
    <a href="index.php" class="btn btn-secondary mb-3">Retour</a>

    <div class="row">
        <?php foreach ($produits as $p): ?>
            <div class="col-md-4">
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($p['nom_produit']) ?></h5>
                        <p><?= htmlspecialchars($p['description']) ?></p>
                        <p><strong><?= $p['prix_vente'] ?> FCFA</strong></p>
                        <a href="panier.php?add=<?= $p['id_produit'] ?>" class="btn btn-success btn-sm">Ajouter au panier</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>
