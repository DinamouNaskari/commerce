<?php
require_once '../includes/auth.php';
require_once '../config/db.php';

if ($_SESSION['role'] !== 'utilisateur') exit("Accès refusé");

$id_produit = $_GET['id'];
$id_utilisateur = $_SESSION['user']['id_utilisateur'];

$stmt = $pdo->prepare("INSERT INTO panier (id_produit, adresse_ip, id_utilisateur, quantite)
                       VALUES (?, ?, ?, 1)");
$stmt->execute([
    $id_produit,
    $_SERVER['REMOTE_ADDR'],
    $id_utilisateur
]);

header("Location: panier.php");
exit;
