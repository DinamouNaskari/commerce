<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'client') {
    header('Location: ../pages/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil Client</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Bienvenue sur votre espace client</h2>
        <a href="produits.php" class="btn btn-primary">Voir les produits</a>
        <a href="panier.php" class="btn btn-warning">Voir le panier</a>
        <a href="../pages/logout.php" class="btn btn-danger">Déconnexion</a>
    </div>
</body>
</html>
