<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'vendeur') {
    header('Location: ../pages/login.php');
    exit;
}

$id_vendeur = $_SESSION['user'];

// Supprimer un produit
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $pdo->prepare("DELETE FROM produits WHERE id_produit = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM fournisseur WHERE id_produit = ? AND id = ?")->execute([$id, $id_vendeur]);
    header("Location: produits.php");
    exit;
}

// Ajouter un produit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom'];
    $prix_achat = $_POST['prix_achat'];
    $prix_vente = $_POST['prix_vente'];
    $quantite = $_POST['quantite'];
    $description = $_POST['description'];
    $id_categorie = $_POST['id_categorie'];
    $id_marque = $_POST['id_marque'];

    $stmt = $pdo->prepare("INSERT INTO produits (nom_produit, prix_achat, prix_vente, quantite, description, id_categorie, id_marque)
                           VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$nom, $prix_achat, $prix_vente, $quantite, $description, $id_categorie, $id_marque]);

    $id_produit = $pdo->lastInsertId();

    // Enregistrer dans fournisseur
    $pdo->prepare("INSERT INTO fournisseur (id, id_produit, id_categorie, nom, prenom) 
                   VALUES (?, ?, ?, '', '')")->execute([$id_vendeur, $id_produit, $id_categorie]);

    header("Location: produits.php");
    exit;
}

// Récupérer produits du vendeur
$stmt = $pdo->prepare("
    SELECT p.*
    FROM produits p
    JOIN fournisseur f ON p.id_produit = f.id_produit
    WHERE f.id = ?
");
$stmt->execute([$id_vendeur]);
$produits = $stmt->fetchAll();

// Catégories et marques
$categories = $pdo->query("SELECT * FROM categories")->fetchAll();
$marques = $pdo->query("SELECT * FROM marques")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Produits du vendeur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Mes Produits</h2>
    <a href="index.php" class="btn btn-secondary mb-3">Retour</a>

    <!-- Formulaire d'ajout -->
    <form method="POST" class="mb-4">
        <div class="row g-2">
            <div class="col-md-4"><input type="text" name="nom" class="form-control" placeholder="Nom du produit" required></div>
            <div class="col-md-2"><input type="number" step="0.01" name="prix_achat" class="form-control" placeholder="Prix achat" required></div>
            <div class="col-md-2"><input type="number" step="0.01" name="prix_vente" class="form-control" placeholder="Prix vente" required></div>
            <div class="col-md-2"><input type="number" name="quantite" class="form-control" placeholder="Quantité" required></div>
            <div class="col-md-6"><textarea name="description" class="form-control" placeholder="Description"></textarea></div>
            <div class="col-md-3">
                <select name="id_categorie" class="form-select" required>
                    <option value="">Catégorie</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id_categorie'] ?>"><?= $cat['nom_categorie'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="id_marque" class="form-select" required>
                    <option value="">Marque</option>
                    <?php foreach ($marques as $m): ?>
                        <option value="<?= $m['id_marque'] ?>"><?= $m['nom_marque'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-success">Ajouter</button>
            </div>
        </div>
    </form>

    <!-- Liste des produits -->
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Nom</th>
                <th>Prix Achat</th>
                <th>Prix Vente</th>
                <th>Quantité</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($produits as $p): ?>
                <tr>
                    <td><?= htmlspecialchars($p['nom_produit']) ?></td>
                    <td><?= $p['prix_achat'] ?></td>
                    <td><?= $p['prix_vente'] ?></td>
                    <td><?= $p['quantite'] ?></td>
                    <td><?= htmlspecialchars($p['description']) ?></td>
                    <td>
                        <a href="?delete=<?= $p['id_produit'] ?>" class="btn btn-danger btn-sm"
                           onclick="return confirm('Supprimer ce produit ?')">Supprimer</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
