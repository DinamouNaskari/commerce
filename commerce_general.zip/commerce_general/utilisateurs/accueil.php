<?php
require_once '../includes/auth.php';
if ($_SESSION['role'] !== 'utilisateur') die("Accès refusé");
include '../includes/header.php';

?>
<h1>Accueil Client</h1>
<p>Bonjour <?= htmlspecialchars($_SESSION['user']['prenom']) ?> !</p>
<?php include '../includes/footer.php'; ?>
