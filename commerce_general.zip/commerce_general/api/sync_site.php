<?php
require_once '../config/db.php';
$data = json_decode(file_get_contents("php://input"), true);

$stmt = $pdo->prepare("INSERT INTO utilisateurs (prenom, nom, email, mot_de_passe, telephone, adresse1, adresse2)
VALUES (?, ?, ?, ?, ?, ?, ?)");

$stmt->execute([
  $data['prenom'],
  $data['nom'],
  $data['email'],
  password_hash($data['mot_de_passe'], PASSWORD_BCRYPT),
  $data['telephone'],
  $data['adresse1'],
  $data['adresse2']
]);

echo json_encode(["status" => "ok"]);
