<?php
session_start();
require_once '../includes/db.php';
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../pages/login.php');
    exit;
}

$logs = $pdo->query("
    SELECT h.*, u.nom, u.prenom 
    FROM historique h
    JOIN utilisateurs u ON h.id_utilisateur = u.id_utilisateur
    ORDER BY h.date DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Historique des actions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Historique des actions</h2>
    <table class="table table-bordered">
        <thead><tr><th>Utilisateur</th><th>Action</th><th>Date</th></tr></thead>
        <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= htmlspecialchars($log['prenom'] . ' ' . $log['nom']) ?></td>
                    <td><?= htmlspecialchars($log['action']) ?></td>
                    <td><?= $log['date'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
