<?php
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $tel = $_POST['telephone'];
    $adresse = $_POST['adresse'];
    $profession = $_POST['profession']; // client, vendeur, livreur
    $mdp = password_hash($_POST['mot_de_passe'], PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("INSERT INTO utilisateurs (prenom, nom, email, mot_de_passe, telephone, adresse, profession)
                           VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$prenom, $nom, $email, $mdp, $tel, $adresse, $profession]);

    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Créer un compte</title>
</head>
<body>
    <h2>Créer un compte</h2>
    <form method="POST">
        <input type="text" name="prenom" placeholder="Prénom" required><br>
        <input type="text" name="nom" placeholder="Nom" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="tel" name="telephone" placeholder="Téléphone" required><br>
        <input type="text" name="adresse" placeholder="Adresse"><br>
        <select name="profession" required>
            <option value="client">Client</option>
            <option value="vendeur">Vendeur</option>
            <option value="livreur">Livreur</option>
        </select><br>
        <input type="password" name="mot_de_passe" placeholder="Mot de passe" required><br>
        <button type="submit">S'inscrire</button>
    </form>
</body>
</html>
