<?php
session_start();
$trx = $_GET['trx'] ?? 'demo123';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Paiement via PayPal</title>
</head>
<body>
<div class="container mt-5">
    <h2>Paiement pour transaction : <?= htmlspecialchars($trx) ?></h2>

    <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
        <input type="hidden" name="business" value="dinamounaskari714@gmail.com">
        <input type="hidden" name="cmd" value="_xclick">
        <input type="hidden" name="item_name" value="Commande <?= $trx ?>">
        <input type="hidden" name="amount" value="1000"> <!-- à adapter -->
        <input type="hidden" name="currency_code" value="USD">
        <input type="hidden" name="return" value="http://tonsite.com/merci.php">
        <input type="submit" value="Payer avec PayPal">
    </form>
</div>
</body>
</html>
