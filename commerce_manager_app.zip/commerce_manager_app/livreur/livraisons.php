<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'livreur') {
    header('Location: ../pages/login.php');
    exit;
}

$id_livreur = $_SESSION['user'];

$stmt = $pdo->prepare("
    SELECT l.*, u.nom, u.prenom, c.id_transaction
    FROM livraison l
    JOIN utilisateurs u ON u.id_utilisateur = l.id_utilisateur
    JOIN commandes c ON c.id_commande = l.id_commande
    WHERE l.id_livreur = ?
");
$stmt->execute([$id_livreur]);
$livraisons = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Mes livraisons</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Mes Livraisons</h2>
    <a href="index.php" class="btn btn-secondary mb-3">Retour</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Client</th>
                <th>ID Commande</th>
                <th>ID Transaction</th>
                <th>Description</th>
                <th>Date Livraison</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($livraisons as $l): ?>
                <tr>
                    <td><?= htmlspecialchars($l['prenom'] . ' ' . $l['nom']) ?></td>
                    <td><?= $l['id_commande'] ?></td>
                    <td><?= $l['id_transaction'] ?></td>
                    <td><?= htmlspecialchars($l['description']) ?></td>
                    <td><?= $l['date_livraison'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
