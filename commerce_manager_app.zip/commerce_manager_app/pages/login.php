<?php
require_once '../includes/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $mdp = $_POST['mot_de_passe'];

    // Rechercher dans la table admin
    $adminStmt = $pdo->prepare("SELECT * FROM administrateurs WHERE email = ?");
    $adminStmt->execute([$email]);
    $admin = $adminStmt->fetch();

    if ($admin && password_verify($mdp, $admin['mot_de_passe']) && $admin['actif'] == '1') {
        $_SESSION['user'] = $admin['id'];
        $_SESSION['role'] = 'admin';
        header('Location: ../admin/index.php');
        exit;
    }

    // Sinon rechercher dans les utilisateurs
    $userStmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ?");
    $userStmt->execute([$email]);
    $user = $userStmt->fetch();

    if ($user && password_verify($mdp, $user['mot_de_passe'])) {
        $_SESSION['user'] = $user['id_utilisateur'];
        $_SESSION['role'] = $user['profession']; // client, vendeur, livreur
        header('Location: dashboard.php');
        exit;
    }

    $error = "Identifiants incorrects.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Connexion</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h2>Connexion</h2>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form method="POST">
        <label>Email :</label><br>
        <input type="email" name="email" required><br><br>
        <label>Mot de passe :</label><br>
        <input type="password" name="mot_de_passe" required><br><br>
        <button type="submit">Connexion</button>
        <a href="register.php">Créer un compte</a>
    </form>
</body>
</html>
