<?php
require_once '../includes/auth.php';
redirectIfNotLoggedIn();

$role = getUserRole();

switch ($role) {
    case 'admin':
        header('Location: ../admin/index.php'); break;
    case 'vendeur':
        header('Location: ../vendeur/index.php'); break;
    case 'client':
        header('Location: ../client/index.php'); break;
    case 'livreur':
        header('Location: ../livreur/index.php'); break;
    default:
        echo "Rôle inconnu.";
}
exit;
