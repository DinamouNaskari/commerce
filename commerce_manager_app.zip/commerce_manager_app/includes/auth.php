<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['user']);
}

function getUserRole() {
    return $_SESSION['role'] ?? null;
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header('Location: ../pages/login.php');
        exit();
    }
}
?>
