</div>
<footer class="text-center mt-4 py-3 bg-light">
    <p>&copy; 2025 - Application Commerce</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/public/js/script.js"></script>
</body>
</html>
