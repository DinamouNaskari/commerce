<?php
require_once '../includes/auth.php';
if ($_SESSION['role'] !== 'admin') exit("Accès refusé");
require_once '../config/db.php';
include '../includes/header.php';

$produits = $pdo->query("SELECT produits.*, marques.nom_marque, categories.nom_categorie
    FROM produits 
    JOIN marques ON produits.id_marque = marques.id_marque
    JOIN categories ON produits.id_categorie = categories.id_categorie
    ORDER BY produits.id_produit DESC")->fetchAll();
?>

<h2>Produits</h2>
<table class="table table-striped">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Marque</th>
            <th>Catégorie</th>
            <th>Prix</th>
            <th>Quantité</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($produits as $p): ?>
        <tr>
            <td><?= htmlspecialchars($p['nom_produit']) ?></td>
            <td><?= htmlspecialchars($p['nom_marque']) ?></td>
            <td><?= htmlspecialchars($p['nom_categorie']) ?></td>
            <td><?= number_format($p['prix'], 2) ?> FCFA</td>
            <td><?= $p['quantite'] ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include '../includes/footer.php'; ?>
